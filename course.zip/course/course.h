#include "student.h"
#include <stdbool.h>

/**
 * @brief creates a typedef struct for course, needs a class name and code and the students in the class
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


