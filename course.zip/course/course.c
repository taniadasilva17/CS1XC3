/**
 * @file course.c
 * @author Tania Da Silva (dasilt2@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief enrolls a student into a course
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //makes the course student list hold the new student
  //if course->total_students is 1, there was originally no students, 
  //meaning you are making a new array to hold the one new student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //if course->total_students is larger than 1, then there was already at 
  //least one student meaning you need to make the original list of students into a new size
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief prints the course information
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //prints every student in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief determines which student has the highest average
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  //if there are no students, no student has the highest average, return NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  //for each student, if their average is higher than the max average, set
  //their average to max avg and set them as the top student, do this for every student in the course
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief determine which students are passing a course
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //count how many students have an average of 50 or greater
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  //for every student, if their average is >= 50, they are passing the course
  //add them to the list of passing students 
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}